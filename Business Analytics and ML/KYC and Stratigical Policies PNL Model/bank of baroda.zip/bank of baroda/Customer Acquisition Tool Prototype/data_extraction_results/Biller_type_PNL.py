from Biller_type_policy import biller_type
import pandas
import csv

class Biller_type_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		results = biller_type()
		data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Billers.csv', sep=',')
		data_original2 = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')
		#workout_sheet = csv.reader('.\policies_data\Results_data_sheets\state_prediction.csv')

		final_result_dict = {}
		for k in set(results):
			with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
				fieldnames = ['Biller Type','Mobile Banking status', 'State','Occupation']
				writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
				writer.writeheader()
				result_dict = {}

				for i in range(len(results)):
					if results[i]==k:
						data = {}
						biller_id = data_original1.loc[i,'Customer ID']
						customer_ids = data_original2.loc[:99,'Customer Id']
						indexing = 0
						for l in customer_ids:
							if biller_id==l:
								break
							indexing += 1
						data_entries_original2 = dict(data_original2.loc[indexing,['Mobile Banking status', 'State', 'Occupation']])
						data.update(data_entries_original2)
						if k==2:
							data.update({'Biller Type':'ELECTRICITY'})
						elif k==3:
							data.update({'Biller Type':'GOVT'})
						elif k==4:
							data.update({'Biller Type':'MOBILE'})
						else:
							data.update({'Biller Type':'SHOP'})
						writer.writerow(data)

			data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
			for j in fieldnames:
				field_data = list(data[j])
				result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})       
			final_result_dict[result_dict['Biller Type']] = result_dict
				
		result_policy_line1  	     = 'The most common behaviour of different billers is described below\n' 
		self.result_policy        	     = result_policy_line1+'\n'.join('\n'.join(' : '.join(str(c) for c in d) for d in i.items()) if type(i)==dict else str(i) for b in final_result_dict.items() for i in b)+'\n\n'
		result_policy_comments_line1 = 'Comments: This policy finds out type of billers, and imortant information about them. Bank developed software applicatin can promoted in those areas. '
		self.result_policy_comments       = result_policy_comments_line1+'Bank can provide some extra benifits to these customers to use bank developed services.'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments
		
	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

