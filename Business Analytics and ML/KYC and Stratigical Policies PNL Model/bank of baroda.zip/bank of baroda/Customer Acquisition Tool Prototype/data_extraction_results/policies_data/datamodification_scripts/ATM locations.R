data = read.csv("ATM.csv")
len = ncol(data)
data$modified_alpha = NA
data$modified_lat = NA
data$modifiedd_lng = NA
data$modified_district = NA
for (i in 1:nrow(data)){
	data[i,"modified_alpha"] = data[i,"alpha"]
	data[i,"modified_lat"] = data[i,"lat"]
	data[i,"modifiedd_lng"] = data[i,"lng"]
	data[i,"modified_district"] = data[i,"district"]}
data = data[-c(1:len)]
write.csv(data, "ATM_regions.csv")