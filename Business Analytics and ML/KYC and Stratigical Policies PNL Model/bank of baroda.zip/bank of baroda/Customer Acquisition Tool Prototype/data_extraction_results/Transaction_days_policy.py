import pandas
from numpy import array
from ml_algoritms.multi_class import multi_class_prediction

def trans_days():
	X_train = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Transaction_data.csv', sep=',', usecols = (1,2,4,5))
	#print X_train
	Y_train = array(pandas.read_csv('.\policies_data\Policies_Data_Sheets\Transaction_data.csv', sep=',', usecols = (3,)))
	#print Y_train
	Y_train = Y_train.flatten()
	X_test = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Transaction_data.csv', sep=',', usecols = (1,2,4,5))
	results = multi_class_prediction(X_train,Y_train,X_test)
	return results
	#print results
