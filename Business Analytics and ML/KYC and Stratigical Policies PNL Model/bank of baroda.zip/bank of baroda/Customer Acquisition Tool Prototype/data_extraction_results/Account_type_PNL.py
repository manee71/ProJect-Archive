''' This PNL predict policies for type of account SBA, CAA , since loss are undefined PNL for profit is not yet implemeted
'''
from Account_type_policy import account_type
import pandas
import csv

class Account_type_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		#<-------------------------------data sheets for policy----------------------------------------------->
		results = account_type()
		data_modified = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Branch_Change.csv', sep=',')
		data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Accounts.csv', sep=',')
		data_original2 = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')

		#<-------------------------------data sheets exported for PNL report---------------------------------->


		with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
			fieldnames = ['branch_change','modified_joint_holder', 'Scheme Code', 'Mode of Operation','Gender', 'State','Occupation']
			writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
			writer.writeheader()
			result_dict = {}

			for i in range(len(results)):
				if results[i]==1:
					data = {}
					data_entries_modified = dict(data_modified.loc[i,['branch_change', 'modified_joint_holder']])
					data.update(data_entries_modified)
					#writer.writerow(data_entries_modified)
					data_entries_original1 = dict(data_original1.loc[i,['Scheme Code','Mode of Operation']])
					data.update(data_entries_original1)
					#writer.writerow(data_entries_original1)
					data_original1_id = data_original1.loc[i,' Customer ID']
					customer_ids = list(data_original2.loc[:99,'Customer Id'])
					#print customer_ids
					indexing = 0
					for i in customer_ids:
						if data_original1_id==i:
							break
						indexing += 1
					data_entries_original2 = dict(data_original2.loc[indexing,['Gender', 'State', 'Occupation']])
					data.update(data_entries_original2)
					writer.writerow(data)

		data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
		for j in fieldnames:
			field_data = list(data[j])
			result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})
				
		self.result_policy 		     = 'The most general behaviour of most common type of account SBA is described below\n'+'\n'.join(' : '.join(str(c) for c in i) for i in result_dict.items())+'\n\n'
		result_policy_comments_line1 = 'Comments: This prediction is about most common account hold  by the customer, it analyze the profile and predict the type of account '
		self.result_policy_comments 	     = result_policy_comments_line1+'customer interested in, it also reflect the lesser effcts of other types of accounts'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments

	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

