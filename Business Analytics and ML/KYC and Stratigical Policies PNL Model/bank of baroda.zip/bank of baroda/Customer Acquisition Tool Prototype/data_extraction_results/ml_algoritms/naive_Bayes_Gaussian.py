#Import Library
from sklearn.naive_bayes import GaussianNB
#Assumed you have, X (predictor) and Y (target) for training data set and x_test(predictor) of test_dataset
def naive_gauss(X,y):
	model = GaussianNB()
	model.fit(X, y)
	return model
	#Predict Output
	#predicted= model.predict(x_test)