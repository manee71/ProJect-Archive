data = read.csv("Lockers.csv")
data$Age = NA
data$modified_Locker_Type = NA
ageDate = as.Date(as.character("11/1/2017"), format = "%m/%d/%Y")
for (i in 1:nrow(data)){
	data[i,"modified_Locker_Type"] = data[i,"Locker.Type"]
	diff = ageDate-as.Date(as.character(data[i,"Last.Rent.Date"]), format="%m/%d/%Y")
	data[i,"Age"]=diff/365}
data = data[-c(1,4:10)]
data = data[1:41,]
write.csv(data,"Locker_data.csv")