import requests
import json
from Tkinter import *
headers = {"apikey": "gQOOO6jnQduiWB0", "Content-Type": "application/json"}


def policy_caller():
    acc = E1.get()
    print ("################################## Get Account List #############################################")
    url = "http://104.211.176.248:8080/bob/bobuat/api/GetAccDetails"
    data = {"Account_Number":acc}
    r = requests.post(url=url,data=json.dumps(data),headers=headers)
    customer_Account_List = r.text
    print (customer_Account_List)


top = Tk()
L1 = Label(top, text="User Name")
L1.pack( side = LEFT)


E1 = Entry(top, bd =5)
E1.pack(side = RIGHT)
B1 = Button(top, text ="Confirm", command = policy_caller, relief='groove', fg='white', bg = 'dark blue')
B1.pack(anchor=CENTER, side = LEFT)
top.mainloop()


