data = read.csv("Branch_Change.csv")
data$Age = NA
data$Available.Balance = NA
data$Funds.in.clearings = NA
data$Drawing.Power = NA
data$Lien.Amt = NA
data2 = read.csv("Accounts.csv")
data1 = read.csv("Customers.csv")
ageDate = as.Date(as.character("11/1/2017"), format = "%m/%d/%Y")
for(i in 1:nrow(data2)){
	data[i,"Available.Balance"] = data2[i,"Available.Balance"]
	data[i,"Funds.in.clearings"] = data2[i,"Funds.in.clearings"]
	data[i,"Drawing.Power"] = data2[i,"Drawing.Power"]
	data[i,"Lien.Amt"] = data2[i,"Lien.Amt"]
	for(j in 1:nrow(data1)){
		if(data2[i,1]==data1[j,1]){
			diff = ageDate-as.Date(as.character(data1[j,"Date.Of.Birth"]), format="%m/%d/%Y")
			data[i,"Age"]=diff/365
			break}}}
data = data[-c(1)]
write.csv(data, "Offerd_scheme.csv")