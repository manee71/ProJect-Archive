data = read.csv("Loan_API22.csv")
data$modified_Interest_Type = NA
data$modified_ForeclosureAllowed = NA
data$modified_PartPayment_Allowed = NA
for (i in 1:nrow(data)){
	data[i,"modified_Interest_Type"] = data[i,"Interest.Type"]
	data[i,"modified_ForeclosureAllowed"] = data[i,"Foreclosure.Allowed"]
	data[i,"modified_PartPayment_Allowed"]  = data[i,"Part.Payment.Allowed"]}
data = data[-c(1,2,8:15)]
data = data[1:44,]
write.csv(data, "Loan_strategy.csv")