data = read.csv("Billers.csv")
len = ncol(data)
data$Gender = NA
data$State = NA
data$Occupation = NA
data$Staffflag = NA
data$modified_Biller_Type = NA
data1 = read.csv("Customers.csv")
for(i in 1:121){
	for(j in 1:nrow(data1)){
		if(data[i,1]==data1[j,1]){
			data[i,"modified_Biller_Type"]=data[i,"Biller.Type"]
			data[i,"Gender"]=data1[j,"Gender"]
			data[i,"State"]=data1[j,"State"]
			data[i,"Occupation"]=data1[j,"Occupation"]
			data[i,"Staffflag"]=data1[j,"Staffflag"]
			break }}}
data = data[-c(1:len)]
data = data[(1:121),]		
write.csv(data, "Biller_type.csv")