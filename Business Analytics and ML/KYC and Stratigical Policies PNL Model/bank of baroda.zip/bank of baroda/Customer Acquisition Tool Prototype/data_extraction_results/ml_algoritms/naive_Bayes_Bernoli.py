#Import Library
from sklearn.naive_bayes import BernoulliNB
#Assumed you have, X (predictor) and Y (target) for training data set and x_test(predictor) of test_dataset
def naive_bernouli(X,y):
	model = BernoulliNB()
	model.fit(X, y)
	return model
	#Predict Output
	#predicted= model.predict(x_test)