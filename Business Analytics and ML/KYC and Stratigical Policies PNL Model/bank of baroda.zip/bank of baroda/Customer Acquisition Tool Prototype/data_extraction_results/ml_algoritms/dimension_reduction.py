#Import Library
from sklearn import decomposition

# Create PCA obeject principal componant analysis
def pca_decomposition(train, test):
	# For Factor analysis
	fa= decomposition.FactorAnalysis()
	# Reduced the dimension of training dataset using PCA
	train_reduced = pca.fit_transform(train)
	#Reduced the dimension of test dataset
	test_reduced = pca.transform(test)
	#For more detail on this, please refer
	return train_reduced, test_reduced