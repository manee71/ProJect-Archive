#Import Library
from sklearn.ensemble import RandomForestClassifier

#Training a model with X (predictor) and Y (target) for training data set 
def randomForest(X,y):
	model= RandomForestClassifier()
	# Train the model using the training sets and check score
	model.fit(X, y)
	return model
	#Predict Output
	#predicted= model.predict(x_test)