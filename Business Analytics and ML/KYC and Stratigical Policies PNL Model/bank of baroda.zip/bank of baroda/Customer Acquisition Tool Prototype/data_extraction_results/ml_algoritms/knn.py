#Import Library
from sklearn.neighbors import KNeighborsClassifier

#Training a  knn model with X (predictor) and Y (target) for training data set 
def knn_classifier(X,y):
	model = KNeighborsClassifier(n_neighbors=6) # default value for n_neighbors is 5
	# Train the model using the training sets and check score
	model.fit(X, y)
	return model
	#Predict Output
	#predicted= model.predict(x_test)