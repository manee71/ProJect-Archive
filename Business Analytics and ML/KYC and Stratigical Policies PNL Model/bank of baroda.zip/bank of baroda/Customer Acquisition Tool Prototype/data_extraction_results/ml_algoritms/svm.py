#Import Library
from sklearn import svm

#From training data X (predictor) and Y (target) create svm model
def svm_classifier(X,y):
	''' create svm model from training data'''
	model = svm.SVC() 
	# Train the model using the training sets and check score
	model.fit(X, y)
	model.score(X, y)
	return model
	#Predict Output
	#predicted= model.predict(x_test)