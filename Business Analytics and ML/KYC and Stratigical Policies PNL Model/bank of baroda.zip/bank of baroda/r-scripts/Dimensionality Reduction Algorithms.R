library(stats)
data <- read.csv('project.csv')
less_data <- data[1:1000,]
train <- less_data[1:500,]
test <- less_data[501:1000,]
pca <- princomp(train, cor=TRUE)
train_reduced <- predict(pca, train)
test_reduced <- predict(pca,test)