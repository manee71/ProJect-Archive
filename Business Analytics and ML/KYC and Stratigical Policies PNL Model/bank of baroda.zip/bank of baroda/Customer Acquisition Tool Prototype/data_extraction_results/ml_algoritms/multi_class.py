from decision_Tree import decisionTree_prediction
from kmean import kmeans_clustering
from knn import knn_classifier
from gbm import gbm_classifier
from linear_Regression import lin_reg
from logistic_Regression import log_reg
from naive_Bayes_Bernoli import naive_bernouli
from naive_Bayes_Gaussian import naive_gauss
from neural_Network import neuralnet_classification
from random_Forest import randomForest
from svm import svm_classifier

def multi_class_prediction(train_X, train_y, test_X):
    tree_model = decisionTree_prediction(train_X, train_y)
    tree_prediction = tree_model.predict(test_X)
    #print tree_prediction
    #print len(tree_prediction)
	
    kmeans_model = kmeans_clustering(train_X)
    kmeans_prediction = kmeans_model.predict(test_X)
    #print len(kmeans_prediction)

    knn_model = knn_classifier(train_X, train_y)
    knn_predictions = knn_model.predict(test_X)
    #print len(knn_predictions)

    gbm_model = gbm_classifier(train_X, train_y)
    gbm_predictions = gbm_model.predict(test_X)
    #print len(gbm_predictions)

    lin_model = lin_reg(train_X, train_y)
    lin_predictions = lin_model.predict(test_X)
    #print len(lin_predictions)

    log_model = log_reg(train_X, train_y)
    log_predictions = log_model.predict(test_X)
    #print len(log_predictions)

    naive_bernouli_model = naive_bernouli(train_X, train_y)
    naive_bernouli_predictions = naive_bernouli_model.predict(test_X)
    #print len(naive_bernouli_predictions)

    naive_gauss_model = naive_gauss(train_X, train_y)
    naive_gauss_predictions = naive_gauss_model.predict(test_X)
    #print len(naive_gauss_predictions)

    neuralnet_model = neuralnet_classification(train_X, train_y)
    neuralnet_predictions = neuralnet_model.predict(test_X)
    #print len(neuralnet_predictions)

    randomForest_model = randomForest(train_X, train_y)
    randomForest_predictions = randomForest_model.predict(test_X)
    #print randomForest_predictions

    svm_model = svm_classifier(train_X, train_y)
    svm_predictions = svm_model.predict(test_X)
    #print len(svm_predictions)

    final_results = []
    for i in range(len(test_X)):
        x = (tree_prediction[i], kmeans_prediction[i], knn_predictions[i], gbm_predictions[i],
             lin_predictions[i], log_predictions[i], naive_bernouli_predictions[i],
             naive_gauss_predictions[i], neuralnet_predictions[i], randomForest_predictions[i], svm_predictions[i])
        lista = list(x)
        y = max(((item, lista.count(item)) for item in set(lista)), key=lambda a: a[1])[0]
        final_results.append(y)
    #print final_results
    return final_results
        
        

    
    
    
    
    
