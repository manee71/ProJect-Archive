data = read.csv("Customers.csv")
data$Age = NA
data$modified_Gender = NA
data$modified_State = NA
data$modified_Occupation = NA
data$modified_Staffflag = NA
data$modified_MobileBanking_status = NA
data$modified_AddressProof_Flag = NA
data$modified_AddressProof_document = NA
ageDate = as.Date(as.character("11/1/2017"), format = "%m/%d/%Y")
for(i in 1:100){
	data[i,"modified_Gender"] = data[i,"Gender"]
	data[i,"modified_State"] = data[i,"State"]
	data[i,"modified_Occupation"]	= data[i,"Occupation"]
	data[i,"modified_Staffflag"] = data[i,"Staffflag"]
	data[i,"modified_MobileBanking_status"] = data[i,"Mobile.Banking.status"]
	data[i,"modified_AddressProof_Flag"] = data[i,"Address.proof.Flag"]
	data[i,"modified_AddressProof_document"] = data[i,"Address.proof.document"]  
	diff = ageDate-as.Date(as.character(data[i,"Date.Of.Birth"]), format="%m/%d/%Y")
	data[i,"Age"]=diff/365}
data = data[-c(1:15,17:27)]
data = data[1:100,]
write.csv(data, "Customer_data.csv")