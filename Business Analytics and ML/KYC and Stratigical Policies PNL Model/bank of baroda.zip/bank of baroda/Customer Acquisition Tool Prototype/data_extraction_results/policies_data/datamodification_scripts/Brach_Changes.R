data = read.csv("Accounts.csv")
len = ncol(data)
data$State = NA
data$Occupation = NA
data$modified_Type_of_account = NA
data$branch_change = NA
data$modified_Account_Status = NA
data$modified_joint_holder = NA
data$modified_Scheme_Code = NA
data$modified_mode_of_operation = NA
data1 = read.csv("Customers.csv")
for(i in 1:nrow(data)){
	data[i,"modified_Type_of_account"] = data[i,"Type.of.account"]
	data[i,"modified_Account_Status"] = data[i,"Acct.Status"]
	data[i,"modified_Scheme_Code"]= data[i,"Scheme.Code"]
	data[i,"modified_mode_of_operation"] = data[i,"Mode.of.Operation"]
	for(j in 1:nrow(data1)){
		if(data[i,1]==data1[j,1]){
			data[i,"State"]=data1[j,"State"]
			data[i,"Occupation"]=data1[j,"Occupation"]
			break}}}

for(i in 1:nrow(data)){
	if ((data[i,"Branch.in.which.Account"]-data[i,"Account.Opening.Branch"])==0){
		data[i,"branch_change"]=0}
	else{
		data[i,"branch_change"]=1}}
for (i in 1:nrow(data)){
	if (data[i,"Joint.Holder.Name.1"]==""){
		data[i,"modified_joint_holder"]=0}
	else{
		data[i,"modified_joint_holder"]=1}}
data = data[-c(1:len)]
write.csv(data, "Branch_Change.csv")