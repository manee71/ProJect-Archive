#Import Library
from sklearn.linear_model import LogisticRegression

#Assumed you have, X (predictor) and Y (target) for training data set and x_test(predictor) of test_dataset
def log_reg(X,y):
	model = LogisticRegression()
	# Train the model using the training sets and check score
	model.fit(X, y)
	model.score(X, y)
	return model
	#Equation coefficient and Intercept
	#print('Coefficient: \n', model.coef_)
	#print('Intercept: \n', model.intercept_)
	#Predict Output
	#predicted= model.predict(x_test)