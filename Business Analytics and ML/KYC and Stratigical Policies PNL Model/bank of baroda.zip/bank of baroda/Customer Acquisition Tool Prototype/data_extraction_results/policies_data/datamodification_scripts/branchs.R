data = read.csv("Branch-Revised.csv")
len = ncol(data)
data$modified_city = NA
data$modified_locker = NA
data$modified_insurance = NA
data$modified_forex = NA
data$modified_invest = NA
for (i in 1:nrow(data)){
	data[i,"modified_city"] = data[i,"city"]
	data[i,"modified_locker"] = data[i,"locker"]
	data[i,"modified_insurance"] = data[i,"insurance"]
	data[i,"modified_forex"] = data[i,"forex"]
	data[i,"modified_invest"] = data[i,"invest"]}

data = data[-c(1:len)]
write.csv(data, "Brach_policies.csv")