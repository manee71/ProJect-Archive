#Import tree module
#U can Import other libraries like pandas, numpy...

from sklearn import tree

#From data X predicting Y
def decisionTree_prediction(X,y):
	''' Give training parameter and it will return train decision tree module'''
	model = tree.DecisionTreeClassifier(criterion='gini') # for classification, here you can change the algorithm as gini or entropy 
	#(information gain) by default it is gini  
	# model = tree.DecisionTreeRegressor() for regression
	# Train the model using the training sets and check score
	model.fit(X, y)
	model.score(X, y)
	return model
	#Predict Output
	#predicted= model.predict(x_test)