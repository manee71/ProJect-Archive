from Branch_has_insurance_policy import branch_insurance
from Branch_has_forex_policy import branch_forex
from Branch_has_invest_policy import branch_invest
from Branch_has_locar_policy import branch_locar
import pandas
import csv

class Branch_has_facility_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		combined_results = [branch_insurance(), branch_forex(), branch_invest(), branch_locar()] 
		data_original2 = pandas.read_csv('.\policies_data\Data_Sheets\Branch-Revised.csv', sep=',')
		#workout_sheet = csv.reader('.\policies_data\Results_data_sheets\state_prediction.csv')
		final_result_dict = {}
		indexing = 0
		for results in combined_results:
			with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
				fieldnames = ['city']
				writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
				writer.writeheader()
				result_dict = {}

				for i in range(len(results)):
					if results[i]==1:
						data = {}
						data_entries_original2 = dict(data_original2.loc[i,['city']])
						data.update(data_entries_original2)
						writer.writerow(data)

			data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
			for j in fieldnames:
				field_data = list(data[j])
				result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})
					
			if indexing==0:
				final_result_dict['Insurance'] = result_dict
			elif indexing==1:
				final_result_dict['Forex'] = result_dict
			elif indexing==2:
				final_result_dict['Invest'] = result_dict
			else:
				final_result_dict['Locker'] = result_dict

			indexing +=1

		result_policy_line1  	     = 'The most general behaviour of Branches with facility is described below\n'
		self.result_policy                = result_policy_line1+ '\n'.join('\n'.join(' : '.join(str(c) for c in d) for d in i.items()) if type(i)==dict else str(i) for b in final_result_dict.items() for i in b)+'\n\n'
		result_policy_comments_line1 = 'Comments: here we will predict the most common city with amount of facility available. Here most in general city is predicted for each type of facility. '
		result_policy_comments_line2 = result_policy_comments_line1+'This information can be rolled out to public to access nearest available branch with required facility. '
		self.result_policy_comments       = result_policy_comments_line2+'This can also be used in promoting bank developed apps, to include facilities and their awareness'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments

	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

