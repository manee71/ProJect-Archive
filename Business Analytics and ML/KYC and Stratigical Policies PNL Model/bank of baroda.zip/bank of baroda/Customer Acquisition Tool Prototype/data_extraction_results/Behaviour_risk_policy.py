import pandas
from numpy import array
from ml_algoritms.multi_class import multi_class_prediction
import tkMessageBox

def behave_risk(individual = False, customer_id=None):
	X_train = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Customer_data.csv', sep=',', usecols = (1,3,4,5,6,7,8,9,10))
	#print X_train
	Y_train = array(pandas.read_csv('.\policies_data\Policies_Data_Sheets\Customer_data.csv', sep=',', usecols = (2,)))
	#print Y_train
	Y_train = Y_train.flatten()
	if individual:
		account_data = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')
		try:
			index = list(account_data['Customer Id']).index(float(customer_id))
		except:
			tkMessageBox.showinfo("Invalid value error","Customer not found")
			return
		X_test_list = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Customer_data.csv', sep=',', usecols = (1,3,4,5,6,7,8,9,10))
		X_test = array(X_test_list.loc[index]).reshape(-1,9)
	else:
		X_test = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Customer_data.csv', sep=',', usecols = (1,3,4,5,6,7,8,9,10))
	results = multi_class_prediction(X_train,Y_train,X_test)
	return results
	#print results
