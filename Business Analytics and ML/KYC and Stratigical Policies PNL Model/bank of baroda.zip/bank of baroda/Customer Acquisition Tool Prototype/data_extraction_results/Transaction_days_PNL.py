''' This PNL predict policies for type of Transactons like  credit, debit. 
'''
from Transaction_days_policy import trans_days
import pandas
import csv


class Transaction_days_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
	
		#<----------------------------------data sheets for policy----------------------------------------------->'''
		results = trans_days()
		data_modified = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Transaction_data.csv', sep=',')
		data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Transactions.csv', sep=',')

		#<-------------------------------data sheets exported for PNL report---------------------------------->


		with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
			fieldnames = ['Tran Amt', 'Transaction type', 'Balance','modified_Tran.Rmks']
			writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
			writer.writeheader()
			result_dict = {}

			for i in range(len(results)):
				if results[i]>=1:
					data = {}
					data_entries_modified = dict(data_modified.loc[i,['modified_Tran.Rmks']])
					data.update(data_entries_modified)
					#writer.writerow(data_entries_modified)
					data_entries_original1 = dict(data_original1.loc[i,['Tran Amt', 'Transaction type', 'Balance']])
					data.update(data_entries_original1)
					writer.writerow(data)

		data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
		for j in fieldnames:
			field_data = list(data[j])
			result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})
			
		self.result_policy        	     = 'The most general behaviour of more than 1 day transaction is described below\n'+'\n'.join(' : '.join(str(c) for c in i) for i in result_dict.items())+'\n\n'
		result_policy_comments_line1 = 'Comments: This prediction is about the transaction taking more than 1 day, (ofcourse we can categorizes other types of transaction like 1day transaction) '
		self.result_policy_comments 	     = result_policy_comments_line1+'Bank can ragulate online services and fast transaction services to affected customers, which will enhance the performance of the bank.'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'


	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments

	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

