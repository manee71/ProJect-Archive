data = read.csv("Transactions.csv")
data$transaction_days = NA
data$modfied_Transaction.type = NA
data$modified_Tran.Rmks = NA
for(i in 1:nrow(data)){
	data[i,"modfied_Transaction.type"] = data[i,"Transaction.type"]
	if(data[i,"Tran.Rmks"]==""){
		data[i,"modified_Tran.Rmks"]=0}
	else{
		data[i,"modified_Tran.Rmks"]=1}
	diff = (as.Date(as.character(data[i,"Tran.Date"]), format="%m/%d/%Y")-
		 as.Date(as.character(data[i,"Value.Date"]), format="%m/%d/%Y"))
	data[i,"transaction_days"] = diff}
data = data[-c(1:5,7,8)]
write.csv(data, "Transaction_data.csv")