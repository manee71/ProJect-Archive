#Import Library
from sklearn.cluster import KMeans

#From test data create cluster
def kmeans_clustering(X):
	''' Create cluster from test data and return the model'''
	model = KMeans(n_clusters=2, random_state=0)
	# Train the model using the training sets and check score
	model.fit(X)
	return model
	#Predict Output
	##predicted= model.predict(x_test)