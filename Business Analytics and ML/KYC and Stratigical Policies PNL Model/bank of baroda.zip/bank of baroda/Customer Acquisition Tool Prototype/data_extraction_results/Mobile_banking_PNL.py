''' This PNL predict the region which is most likely not using internet banking 
'''
from Mobile_banking_policy import mob_banking
import pandas
import csv

class Mobile_banking_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		#<----------------------------------data sheets for policy----------------------------------------------->'''
		results = mob_banking()
		data_modified = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Customer_data.csv', sep=',')
		data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')

		#<-------------------------------data sheets exported for PNL report---------------------------------->


		final_result_dict = {}
		for k in set(results):
			with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
				fieldnames = ['State','Occupation','Internet banking Status', 'Mobile Banking status']
				writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
				writer.writeheader()
				result_dict = {}

				for i in range(len(results)):
					if results[i]==k:
						data = {}
						data_entries_original1 = dict(data_original1.loc[i,['State','Occupation','Internet banking Status']])
						data.update(data_entries_original1)
						if k==3:
							data.update({'Mobile Banking status':'Yes'})
						else:
							data.update({'Mobile Banking status':'No'})
						writer.writerow(data)

			data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
			for j in fieldnames:
				field_data = list(data[j])
				result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})       
			final_result_dict[result_dict['Mobile Banking status']] = result_dict

			
		result_policy_line1          = 'The most general behaviour of mobile banking by customers is described below\n'
		self.result_policy        	     = result_policy_line1+'\n'.join('\n'.join(' : '.join(str(c) for c in d) for d in i.items()) if type(i)==dict else str(i) for b in final_result_dict.items() for i in b)+'\n\n'
		result_policy_comments_line1 = 'Comments: This is one of the most important part of mordern banking system, less number of mobile banking shows bank\'s less effective online banking application '
		self.result_policy_comments 	     = result_policy_comments_line1+'In this policy we predicted the region that is suing less number of internet banking. Bank can regulate new applications and awareness to increase mobile banking.'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments

	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

