data = read.csv("Cheque issuance.csv")
len = ncol(data)
data1 = read.csv("Account_type.csv")
data$Type_of_account = NA
data$Branch_Change_Status = NA
data$Acct_Status = NA
data$Is_Shared = NA
data$Mode_of_Operation = NA
data$modified_Sub_Category = NA
data$modified_SAN_Type = NA 
for (i in 1:nrow(data)){
	data[i,"modified_Sub_Category"] = data[i,"Sub.Category"]
	data[i,"modified_SAN_Type"] = data[i,"SAN.Type"]
	data[i,"Type_of_account"] = data1[i,"Type.of.account"]
	data[i,"Branch_Change_Status"] = data1[i,"Branch.in.which.Account"]
	data[i,"Acct_Status"] = data1[i,"Acct.Status"]
	data[i,"Is_Shared"] = data1[i,"Account.Opening.Branch"]
	data[i,"Mode_of_Operation"] = data1[i,"Mode.of.Operation"]}
data = data[-c(1:len)]
write.csv(data, "Cheque_books.csv")