''' Predict whether account going to deactive in future and predict future loss for bank, aslo put a sanity caheck for new account
'''
from Account_Status_Policy import account_Status
import pandas
import csv

class Account_Status_class(object):
    def __init__(self, individual=False, account_no=None):
        self.individual = individual
        self.account_no = account_no

    def data_processing(self):
        
        results = account_Status(self.individual,self.account_no)
        data_modified = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Branch_Change.csv', sep=',')
        data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Accounts.csv', sep=',')
        data_original2 = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')

        data_Transactons = pandas.read_csv('.\policies_data\Data_Sheets\Transactions.csv', sep=',')

        with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
            fieldnames = ['branch_change','modified_joint_holder','Type of account', 'Scheme Code', 'Mode of Operation','Gender', 'State','Occupation','Behaviour Risk Score']
            writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
            writer.writeheader()
            result_dict = {}
            loss_count_Transactons = 0
            loss_count_Loan = 0
            Total_true_cases = 0

            if results:
                for i in range(len(results)):
                    if results[i]==2:
                        data = {}
                        data_entries_modified = dict(data_modified.loc[i,['branch_change', 'modified_joint_holder']])
                        data.update(data_entries_modified)
                        #writer.writerow(data_entries_modified)
                        data_entries_original1 = dict(data_original1.loc[i,['Type of account','Scheme Code','Mode of Operation']])
                        data.update(data_entries_original1)
                        #writer.writerow(data_entries_original1)
                        data_original1_id = data_original1.loc[i,' Customer ID']
                        data_original1_account = data_original1.loc[i,'Account Number']
                        loss_count_Transactons += list(data_Transactons['Accounts Number']).count(data_original1_account)
                        if data_original1.loc[i,'Available Balance']>=250000:
                            loss_count_Loan+=1
                        customer_ids = list(data_original2.loc[:99,'Customer Id'])
                        #print customer_ids
                        indexing = 0
                        for i in customer_ids:
                            if data_original1_id==i:
                                break
                            indexing += 1
                        data_entries_original2 = dict(data_original2.loc[indexing,['Gender', 'State', 'Occupation', 'Behaviour Risk Score']])
                        data.update(data_entries_original2)
                        writer.writerow(data)
                        Total_true_cases += 1

        data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
        for j in fieldnames:
            field_data = list(data[j])
            result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})

        accountLoss = loss_count_Transactons*5
        loan_loss = loss_count_Loan*100
        result_PNL_dict = {'Total predicted deactivated accounts':Total_true_cases, 'Total loss predicted from transaction': accountLoss,
                           'Total loss predicted from loan policy': loan_loss, 'Total loss to bank': accountLoss+loan_loss} 
                                           
        self.result_policy 		     = 'The most general behaviour of deactivated account is described below\n'+'\n'.join(' : '.join(str(c) for c in i) for i in result_dict.items()) +'\n\n'
        result_policy_comments_line1 = 'Comments: From this policy, we can predict that which is going to deactivate in future, or customer will decide to move out of the bank. '
        result_policy_comments_line2 = result_policy_comments_line1+'This will cause potential harm to bank, PNL for available data can be found in second text box. '
        self.result_policy_comments       = result_policy_comments_line2+'To avoid possible harms, bank can ragulate benifits policies and awareness of these policies for these sets of customers.'
        self.result_PNL 		     = 'Total loss occurance due to customer account deactivation\n'+'\n'.join(' : '.join(str(c) for c in i) for i in result_PNL_dict.items())+'\n\n'
        result_PNL_comments_line1    = 'Comments: This is a predicted loss for the customers whose account will be deactivated in future(predicted losses)\n '
        result_PNL_comments_line2    = result_PNL_comments_line1+'Note: this prediction is only for given data, it can be tested on any large no of data, the attributes '
        result_PNL_comments_line3    = result_PNL_comments_line2+'contributing in calculation are described above, these are simple ones, bank can decide how they want to evalute their losses. '
        self.result_PNL_comments          = result_PNL_comments_line3+'This can be implemented in full model'

    def return_policy(self):
        return self.result_policy
            
    def policy_comments(self):
        return self.result_policy_comments

    def  return_PNL(self):
        return self.result_PNL

    def PNL_comments(self):
        return self.result_PNL_comments
