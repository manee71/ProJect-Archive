from Cstomer_Age_policy import cust_age
import pandas
import csv

class Cstomer_Age_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		results = cust_age()
		data_original2 = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')
		#workout_sheet = csv.reader('.\policies_data\Results_data_sheets\state_prediction.csv')
		final_result_dict = {}

		ageGroupList = [[21,26],[26,31],[31,36],[36,41],[41,46],[46,51],[51,56],[56,61],[61,200]]
		for k in ageGroupList:
			with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
				fieldnames = ['Annual Total Income', 'Address proof Flag','Gender', 'State','Occupation','Age', 'Behaviour Risk Score']
				writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
				writer.writeheader()
				result_dict = {}

				for i in range(len(results)):
						data = {}
						if results[i]>=k[0] and results[i]<k[1]:
							data_entries_modified = {'Age': 'Age Group %s to %s'%(str(k[0]),str(k[1]))}
							data.update(data_entries_modified)
						else:
							continue
							
						data_entries_original2_income = dict(data_original2.loc[i,['Annual Total Income']])
						if data_entries_original2_income['Annual Total Income'] in range(1,250001):
							data_entries_original2_income.update({'Annual Total Income': 'Non Taxable group'})
						elif data_entries_original2_income['Annual Total Income'] in range(250001,500001):
							data_entries_original2_income.update({'Annual Total Income': 'Taxable group income 250001 to 500000'})
						elif data_entries_original2_income['Annual Total Income'] in range(500001,1000001):
							data_entries_original2_income.update({'Annual Total Income': 'Taxable group income 500001 to 1000000'})
						else:
							data_entries_original2_income.update({'Annual Total Income': 'Taxable group income more than 1000000'})
						data.update(data_entries_original2_income)
								
						data_entries_original2 = dict(data_original2.loc[i,['Address proof Flag','Gender', 'State','Occupation','Behaviour Risk Score']])
						data.update(data_entries_original2)
						writer.writerow(data)

			data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
			for j in fieldnames:
				field_data = list(data[j])
				result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})
			final_result_dict[result_dict['Age']] = result_dict

		result_policy_line1          = 'Results: The most common behaviour of customers with different age group is described below:\n'
		self.result_policy                = result_policy_line1+ '\n'.join('\n'.join(' : '.join(str(c) for c in d) for d in i.items()) if type(i)==dict else str(i) for b in final_result_dict.items() for i in b)+'\n\n'
		result_policy_comments_line1 = 'Comments: These results shows the predicted members in different age group, from this data we can find out the most profitable age Group. '
		result_policy_comments_line2 = result_policy_comments_line1+'Most common data for each group is collected individually, from this  we can targate our potential customers.\n\n'
		self.result_policy_comments       = result_policy_comments_line2+'Note: In this demo we focused on a uniiversal strategy, we can move to specifc strategy in full model'
		self.result_PNL                   = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments
		
	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

