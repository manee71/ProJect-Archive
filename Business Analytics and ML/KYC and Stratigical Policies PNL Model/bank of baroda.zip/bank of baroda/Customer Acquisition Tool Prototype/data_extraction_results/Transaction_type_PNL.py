''' This PNL predict policies for type of Transactons like  credit, debit. 
'''
from Transaction_type_policy import trans_type
import pandas
import csv

class Transaction_type_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		#<-------------------------------data sheets for policy----------------------------------------------->
		results = trans_type()
		data_modified = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Transaction_data.csv', sep=',')


		#<-------------------------------data sheets exported for PNL report---------------------------------->


		final_result_dict = {}
		for k in set(results):
			with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
				fieldnames = ['Transaction type','Tran.Amt', 'Balance','transaction_days','modified_Tran.Rmks']
				writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
				writer.writeheader()
				result_dict = {}

				for i in range(len(results)):
					if results[i]==k:
						data = {}
						data_entries_original2 = dict(data_modified.loc[i,['Tran.Amt', 'Balance','transaction_days','modified_Tran.Rmks']])
						data.update(data_entries_original2)
						if k==1:
							data.update({'Transaction type':'Credit'})
						else:
							data.update({'Transaction type':'Debit'})
						writer.writerow(data)

			data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
			for j in fieldnames:
				field_data = list(data[j])
				result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})       
			final_result_dict[result_dict['Transaction type']] = result_dict
			
		result_policy_line1  	     = 'The most common behaviour of different Types of transactions made by customer accounts is described below\n' 
		self.result_policy        	     = result_policy_line1+'\n'.join('\n'.join(' : '.join(str(c) for c in d) for d in i.items()) if type(i)==dict else str(i) for b in final_result_dict.items() for i in b)+'\n\n'
		result_policy_comments_line1 = 'Comments: This prediction is about the type of transaction customers will be making based on there needs. It bill predict their future transactions. '
		self.result_policy_comments 	     = result_policy_comments_line1+'Bank can ragulate some services to ease the process and comfort for their customers'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments

	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

