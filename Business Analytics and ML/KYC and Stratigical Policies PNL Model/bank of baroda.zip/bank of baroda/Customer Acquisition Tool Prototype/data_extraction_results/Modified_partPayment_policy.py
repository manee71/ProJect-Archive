import pandas
from numpy import array
from ml_algoritms.multi_class import multi_class_prediction

X_train = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Loan_strategy.csv', sep=',', usecols = (1,2,3,4,6))
#print X_train
Y_train = array(pandas.read_csv('.\policies_data\Policies_Data_Sheets\Loan_strategy.csv', sep=',', usecols = (8,)))
#print Y_train
Y_train = Y_train.flatten()
X_test = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Loan_strategy.csv', sep=',', usecols = (1,2,3,4,6))
results = multi_class_prediction(X_train,Y_train,X_test)
print results
