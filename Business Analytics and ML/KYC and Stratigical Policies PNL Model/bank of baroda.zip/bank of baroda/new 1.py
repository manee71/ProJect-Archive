import requests
import json

headers = {"apikey": "gQOOO6jnQduiWB0", "Content-Type": "application/json"}


print ("################################## Get Account List #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/GetCustAccList"
data = {"Customer_Id":440728117}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
customer_Account_List = r.text
print (customer_Account_List)

print ("################################## Get Account Details #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/GetAccDetails"
data = {"Account_Number":29040100001234}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
customer_Account_Details = r.text
print (customer_Account_Details)

print("################################## Get Transaction for account #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/GetTransc4Account"
data = {"Account_Number":00430100001323, "Type_of_Account":"SBA", "From_Date":20170901, "To_Date":20170915}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
customer_Transaction_Details = r.text
print (customer_Transaction_Details)

print ("################################## Get mini statement for account with Journal #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/GetMiniState4anAccount"
data = {"Account_Number":00430100001323}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
customer_MiniStatement_Journal_Details = r.text
print (customer_MiniStatement_Journal_Details)

print ("################################## Get mini statement for account with Journal #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/GetMiniState4anAccount"
data = {"Account_Number":00430100001323}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
customer_MiniStatement_Journal_Details = r.text
print (customer_MiniStatement_Journal_Details)

print ("################################## Get Customers Details #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/GetCustDetails"
data = {"Customer_Id":526814203}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
customer_Details = r.text
print (customer_Details)

print ("################################## Modify Customers Details #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/ModifyCustDetails"
data = {"Customer_Id":"526814203", "Mod_Param":"Line_Address_2", "Mod_Value":"Blah Blah Balh", "Mod_Kyc_Doc":"Rental Agreement"}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
modify_Details = r.text
print (modify_Details)

print ("################################## Customers Mod Status Enquiry Details #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/CustDetailsModStatusEnquiry"
data = {"Customer_Id":"526814203", "SER_REF_NO": "CDM20171015074406"}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
mod_Status_Enquiry_Details = r.text
print (mod_Status_Enquiry_Details)

print ("################################## Customers Mod Status Enquiry Details #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/CustDetailsModStatusEnquiry"
data = {"Customer_Id":"526814203", "SER_REF_NO": "CDM20171015074406"}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
mod_Status_Enquiry_Details = r.text
print (mod_Status_Enquiry_Details)

print ("################################## Get KYC Details #############################################")
url = "http://104.211.176.248:8080/bob/bobuat/api/GetKYCDetails"
data = {"Customer_Id":"526814203"}
r = requests.post(url=url,data=json.dumps(data),headers=headers)
kyc_Details = r.text
print (kyc_Details)
