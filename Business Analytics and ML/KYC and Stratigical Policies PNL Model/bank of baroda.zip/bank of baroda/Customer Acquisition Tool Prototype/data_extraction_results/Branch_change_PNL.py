from Branch_change_policy import branch_change
import pandas
import csv

class Branch_Change_class(object):
	
	def __init__(self, individual=False, account_no=None):
		self.individual = individual
		self.account_no = account_no
		
	def data_processing(self):
		results = branch_change(self.individual,self.account_no)
		data_modified = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Branch_Change.csv', sep=',')
		data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Accounts.csv', sep=',')
		data_original2 = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')
		#workout_sheet = csv.reader('.\policies_data\Results_data_sheets\state_prediction.csv')

		with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
			fieldnames = ['modified_Account_Status','modified_joint_holder','Type of account', 'Scheme Code', 'Mode of Operation','Gender', 'State','Occupation']
			writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
			writer.writeheader()
			result_dict = {}

                        if results:
                                for i in range(len(results)):
                                        if results[i]==1:
                                                data = {}
                                                data_entries_modified = dict(data_modified.loc[i,['modified_Account_Status', 'modified_joint_holder']])
                                                data.update(data_entries_modified)
                                                #writer.writerow(data_entries_modified)
                                                data_entries_original1 = dict(data_original1.loc[i,['Type of account','Scheme Code','Mode of Operation']])
                                                data.update(data_entries_original1)
                                                #writer.writerow(data_entries_original1)
                                                data_original1_id = data_original1.loc[i,' Customer ID']
                                                customer_ids = list(data_original2.loc[:99,'Customer Id'])
                                                #print customer_ids
                                                indexing = 0
                                                for i in customer_ids:
                                                        if data_original1_id==i:
                                                                break
                                                        indexing += 1
                                                data_entries_original2 = dict(data_original2.loc[indexing,['Gender', 'State', 'Occupation']])
                                                data.update(data_entries_original2)
                                                writer.writerow(data)

		data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
		for j in fieldnames:
			field_data = list(data[j])
			result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})

		self.result_policy  		     = 'The most common Behaviour in branch changes is described below\n'+'\n'.join(' : '.join(str(c) for c in i) for i in result_dict.items())+'\n\n' 
		result_policy_comments_line1 = 'Comments: this policy is about cutomer changing their branches, it will figure out what kind of customers are changing there '
		self.result_policy_comments	     = result_policy_comments_line1+'braches and for what reason, which will help us in improving facility in braches.'
		self.result_PNL		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'	

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments
		
	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

