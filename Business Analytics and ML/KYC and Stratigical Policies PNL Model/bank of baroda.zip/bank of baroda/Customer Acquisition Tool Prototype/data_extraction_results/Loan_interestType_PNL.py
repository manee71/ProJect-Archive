''' This PNL predict policies for type of Transactons like  credit, debit. 
'''
from Loan_interestType_policy import loan_intRate
import pandas
import csv

class Loan_interestType_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		#<----------------------------------data sheets for policy----------------------------------------------->'''
		results = loan_intRate()
		data_modified = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Loan_strategy.csv', sep=',')
		data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Loan_API22.csv', sep=',')

		#<-------------------------------data sheets exported for PNL report---------------------------------->


		final_result_dict = {}
		for k in set(results):
			with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
				fieldnames = ['Interest Type','Product Scheme','Minimum Tenure in months', 'Maximum Tenure in months','Minimum Amount','Maximum Amount','Rate of Interest','Foreclosure Allowed','Part Payment Allowed']
				writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
				writer.writeheader()
				result_dict = {}

				for i in range(len(results)):
					if results[i]==k:
						data = {}
						data_entries_original1 = dict(data_original1.loc[i,['Product Scheme','Minimum Tenure in months', 'Maximum Tenure in months','Minimum Amount','Maximum Amount',
																						   'Rate of Interest','Foreclosure Allowed','Part Payment Allowed']])
						data.update(data_entries_original1)
						if k==2:
							data.update({'Interest Type':'Fixed'})
						else:
							data.update({'Interest Type':'FLOATING'})
						writer.writerow(data)

			data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
			for j in fieldnames:
				field_data = list(data[j])
				result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})       
			final_result_dict[result_dict['Interest Type']] = result_dict
			
		result_policy_line1          = 'The most general behaviour for type of interest rates offered by bank is described below\n'
		self.result_policy        	     = result_policy_line1+'\n'.join('\n'.join(' : '.join(str(c) for c in d) for d in i.items()) if type(i)==dict else str(i) for b in final_result_dict.items() for i in b)+'\n\n'
		result_policy_comments_line1 = 'Comments: This prediction is about predictig behaviour of type of interest rates offered by the bank, if a scheme satisfy certain criteria then type of interest rate can '
		self.result_policy_comments 	     = result_policy_comments_line1+'be predicted for that cheme. Bank can use this policy to predict the type of interest rates for upcoming policies.'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments

	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

