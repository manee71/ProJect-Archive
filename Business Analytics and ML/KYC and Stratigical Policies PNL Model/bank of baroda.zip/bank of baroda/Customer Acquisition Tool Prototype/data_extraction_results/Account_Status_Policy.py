import pandas
from numpy import array
from ml_algoritms.multi_class import multi_class_prediction
import tkMessageBox

def account_Status(individual = False, Account_no=None):
        X_train = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Branch_Change.csv', sep=',', usecols = (1,2,3,4,6,7,8))
        #print X_train
        Y_train = array(pandas.read_csv('.\policies_data\Policies_Data_Sheets\Branch_Change.csv', sep=',', usecols = (5,)))
        #print Y_train
        Y_train = Y_train.flatten()
        if individual:
		account_data = pandas.read_csv('.\policies_data\Data_Sheets\Accounts.csv', sep=',')
		try:
			index = list(account_data['Account Number']).index(Account_no)
		except:
			tkMessageBox.showinfo("Invalid value error","Account not found")
			return
		X_test_list = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Branch_Change.csv', sep=',', usecols = (1,2,3,4,6,7,8))
		X_test = array(X_test_list.loc[index]).reshape(-1,7)
	else:
		X_test = pandas.read_csv('.\policies_data\Policies_Data_Sheets\Branch_Change.csv', sep=',', usecols = (1,2,3,4,6,7,8))
        results = multi_class_prediction(X_train,Y_train,X_test)
        return results
