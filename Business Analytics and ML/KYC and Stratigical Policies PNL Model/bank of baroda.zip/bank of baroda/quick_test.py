from Tkinter import *

root = Tk()
scrollbar = Scrollbar(root, activebackground='green', bg='green', troughcolor='green')
scrollbar.pack( side = RIGHT, fill = Y )

mylist = Listbox(root, yscrollcommand = scrollbar.set, bg='light yellow', relief='groove',height=5, fg='dark blue' )
for line in range(100):
   mylist.insert(END, "This is line number " + str(line))

mylist.pack( side = LEFT, fill = BOTH )
scrollbar.config( command = mylist.yview )

mainloop()
