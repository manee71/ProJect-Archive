''' This PNL predict policies for type of Transactons like  credit, debit. 
'''
from Offered_scheme_policy import offered_scheme
import pandas
import csv

class Offered_scheme_class(object):

	def __init__(self):
		pass
		
	def data_processing(self):
		#<----------------------------------data sheets for policy----------------------------------------------->'''
		results = offered_scheme()
		data_original1 = pandas.read_csv('.\policies_data\Data_Sheets\Accounts.csv', sep=',')
		data_original2 = pandas.read_csv('.\policies_data\Data_Sheets\Customers.csv', sep=',')

		#<-------------------------------data sheets exported for PNL report---------------------------------->

		scheme_dict = {1:'CA101',2:'SB112',3:'SB112',4:'SB113',5:'SB114',6:'SB115',7:'SB123',8:'SB124',9:'SB130',10:'SB133',11:'SB134',12:'SB135',13:'SB101',14:'SB154',15:'SB201'}
		final_result_dict = {}
		for k in set(results):
			with open('.\policies_data\Results_data_sheets\state_prediction.csv', 'w') as workout_sheet:
				fieldnames = ['Scheme Code','Occupation','State']
				writer = csv.DictWriter(workout_sheet, fieldnames = fieldnames)
				writer.writeheader()
				result_dict = {}

				for i in range(len(results)):
					if results[i]==k:
						data = {}
						customer_id = data_original1.loc[i,' Customer ID']
						index = list(data_original2['Customer Id']).index(customer_id)
						data_entries_original2 = dict(data_original2.loc[index,['State','Occupation']])
						data.update(data_entries_original2)
						data.update({'Scheme Code':scheme_dict[k]})
						writer.writerow(data)

			data = pandas.read_csv('.\policies_data\Results_data_sheets\state_prediction.csv', sep=',')
			for j in fieldnames:
				field_data = list(data[j])
				result_dict.update({j: max(((item, field_data.count(item)) for item in set(field_data)), key=lambda a: a[1])[0]  if len(field_data) else 'None'})       
			final_result_dict[result_dict['Scheme Code']] = result_dict
			
		result_policy_line1          = 'The most general behaviour for type of schemes offered by bank is described below\n'
		self.result_policy        	     = result_policy_line1+'\n'.join('\n'.join(' : '.join(str(c) for c in d) for d in i.items()) if type(i)==dict else str(i) for b in final_result_dict.items() for i in b)+'\n\n'
		result_policy_comments_line1 = 'Comments: This prediction is about predictig behaviour of type of scheme offered by bank, a common behaviour related to most common scheme is predicted, '
		self.result_policy_comments 	     = result_policy_comments_line1+' Bank can use this policy to enhance these policy or modify these policies for those related data.'
		self.result_PNL 		     = 'PNL report is not described for this part. PNL is only for lossy part. Overall PNL will be developed in full model development.'+'\n\n'
		self.result_PNL_comments          = 'No PNL Found, available in fully developed model'

	def return_policy(self):
		return self.result_policy
		
	def policy_comments(self):
		return self.result_policy_comments

	def return_PNL(self):
		return self.result_PNL
		
	def PNL_comments(self):
		return self.result_PNL_comments

