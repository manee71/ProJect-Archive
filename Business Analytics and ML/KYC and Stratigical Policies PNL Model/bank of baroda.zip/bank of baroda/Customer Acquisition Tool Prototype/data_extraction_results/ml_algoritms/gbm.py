#Import Library
from sklearn.ensemble import GradientBoostingClassifier

#Train model with X (predictor) and Y (target) for training data set 
def gbm_classifier(X,y):
	model= GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=1, random_state=0)
	# Train the model using the training sets and check score
	model.fit(X, y)
	return model
	#Predict Output
	#predicted= model.predict(x_test)