from Tkinter import*
import requests
import json
from Biller_type_PNL import Biller_type_class
from Account_Status_PNL import Account_Status_class
from Account_type_PNL import Account_type_class
from Joint_holder_PNL import Joint_holder_class
from Drawing_power_PNL import Drawing_power_class
from Customer_income_PNL import Customer_income_class
from Cstomer_Age_PNL import Cstomer_Age_class
from Branch_in_city_PNL import Branch_in_city_class
from Branch_has_facility_PNL import Branch_has_facility_class
from Branch_change_PNL import Branch_Change_class
from Behaviour_risk_PNL import Behaviour_risk_class
from Available_balance_PNL import Available_balance_class
from AddressProof_flag_PNL import AddressProof_flag_class
from AddressProof_Document_PNL import AddressProof_Document_class
from Transaction_type_PNL import Transaction_type_class
from Transaction_remarks_PNL import Transaction_remarks_class
from Transaction_days_PNL import Transaction_days_class
from Offered_scheme_PNL import Offered_scheme_class
from Mobile_banking_PNL import Mobile_banking_class
from Loan_interestType_PNL import Loan_interestType_class
from Occupation_of_accountHoler_PNL import Occupation_of_accountHoler_class
import tkMessageBox
root = Tk()
#<-----------------Original Frame---------------->
root.geometry('1350x690+0+0')
root.title('Customer Acquisition Tool')

#<-----------------Top Part of Frame----------------->
Top_part = LabelFrame(root, width=800, height=100, text='Select an appropriate type of policy')   
Top_part.pack(side=TOP)
#<-------------------Sub Division of Top Frame-------->
Top_part1 = Frame(Top_part, width= 800, height=10)
Top_part1.pack(side = TOP)
Top_part2 = Frame(Top_part, width=800, height=70)
Top_part2.pack(side = TOP)
Top_part3 = Frame(Top_part, width=800, height=20)
Top_part3.pack(side = BOTTOM)
#<------------Header for customer data request------------------->
headers = {"apikey": "gQOOO6jnQduiWB0", "Content-Type": "application/json"}

#<----------------------Info extraction from all PNLs goes here---->

def set_info():
    if len(MyList_sub.curselection()):
        policy = MyList_sub.get(MyList_sub.curselection()[0])
        if policy=='Account_Status_Policy' or policy=='Branch_change_policy':
            var.set("Enter Account No")
        elif policy=='Behaviour_risk_policy':
            var.set("Enter Customer ID")
        else:
            C1.deselect()
            tkMessageBox.showinfo("Important Info", "Not abailable yet")


def get_pnl():
    if len(MyList_sub.curselection()):
        text0.delete('1.0',END)
        text1.delete('1.0',END)
        policy = MyList_sub.get(MyList_sub.curselection()[0])
        if policy=='Biller_type_policy':
            data = Biller_type_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Occupation_of_billers_policy':
            tkMessageBox.showinfo("Important Info", "PNL not yet implemented")
            text0.insert(INSERT,"PNL not yet implemented")
            text1.insert(INSERT,"PNL not yet implemented")
        elif policy=='Branch_has_facilities_policy':
            data = Branch_has_facility_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Branch_in_city_policy':
            data = Branch_in_city_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Mode_of_operation_policy':
            tkMessageBox.showinfo("Important Info", "PNL not yet implemented")
            text0.insert(INSERT,"PNL not yet implemented")
            text1.insert(INSERT,"PNL not yet implemented")
        elif policy=='Joint_holder_policy':
            data = Joint_holder_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Offered_scheme_policy':
            data = Offered_scheme_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Occupation_of_account_holder_policy':
            data = Occupation_of_accountHoler_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Account_Status_Policy':
            if CheckVar.get():
                C1.deselect()
                acc = E1.get()
                url = "http://104.211.176.248:8080/bob/bobuat/api/GetAccDetails"
                data = {"Account_Number":acc}
                r = requests.post(url=url,data=json.dumps(data),headers=headers)
                customer_Account_List = r.text
                data = Account_Status_class(True,acc)
                data.data_processing()
                tkMessageBox.showinfo("Showing results for following Account", customer_Account_List)
            else:
                data = Account_Status_class()
                data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Account_type_policy':
            data = Account_type_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Branch_change_policy':
            if CheckVar.get():
                C1.deselect()
                acc = E1.get()
                url = "http://104.211.176.248:8080/bob/bobuat/api/GetAccDetails"
                data = {"Account_Number":acc}
                r = requests.post(url=url,data=json.dumps(data),headers=headers)
                customer_Account_List = r.text
                data = Branch_Change_class(True,acc)
                data.data_processing()
                tkMessageBox.showinfo("Showing results for following Account", customer_Account_List)
            else:
                data = Branch_Change_class()
                data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Loan_interestType_policy':
            data = Loan_interestType_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Modified_partPayment_policy':
            tkMessageBox.showinfo("Important Info", "PNL not yet implemented")
            text0.insert(INSERT,"PNL not yet implemented")
            text1.insert(INSERT,"PNL not yet implemented")
        elif policy=='SAN_type_policy':
            tkMessageBox.showinfo("Important Info", "PNL not yet implemented")
            text0.insert(INSERT,"PNL not yet implemented")
            text1.insert(INSERT,"PNL not yet implemented")
        elif policy=='Staffflag_policy':
            tkMessageBox.showinfo("Important Info", "PNL not yet implemented")
            text0.insert(INSERT,"PNL not yet implemented")
            text1.insert(INSERT,"PNL not yet implemented")
        elif policy=='Mobile_banking_policy':
            data = Mobile_banking_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='AddressProof_Document_policy':
            data = AddressProof_Document_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='AddressProof_flag_policy':
            data = AddressProof_flag_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Behaviour_risk_policy':
            if CheckVar.get():
                C1.deselect()
                customer_id = E1.get()
                url = "http://104.211.176.248:8080/bob/bobuat/api/GetCustDetails"
                data = {"Customer_Id":customer_id}
                r = requests.post(url=url,data=json.dumps(data),headers=headers)
                customer_Datails_List = r.text
                data = Behaviour_risk_class(True,customer_id)
                data.data_processing()
                tkMessageBox.showinfo("Showing results for following Customer", customer_Datails_List)
            else:
                data = Behaviour_risk_class()
                data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Cstomer_Age_policy':
            data = Cstomer_Age_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Customer_income_policy':
            data = Customer_income_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Available_balance_policy':
            data = Available_balance_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Drawing_power_policy':
            data = Drawing_power_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Transaction_days_policy':
            data = Transaction_days_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Transaction_remarks_policy':
            data = Transaction_remarks_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        elif policy=='Transaction_type_policy':
            data = Transaction_type_class()
            data.data_processing()
            text0.insert(INSERT,data.return_policy())
            text0.insert(INSERT,data.policy_comments())
            text1.insert(INSERT,data.return_PNL())
            text1.insert(INSERT,data.PNL_comments())
        else:
            print 'Policy Not Found'


def policy_caller():
    if len(MyList.curselection()):
        MyList_sub.delete(0,END)
        if MyList.curselection()[0]==0:
            List_sub = ['Biller_type_policy','Occupation_of_billers_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)
        elif MyList.curselection()[0]==1:
            List_sub = ['Branch_has_facilities_policy','Branch_in_city_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)
            
        elif MyList.curselection()[0]==2:
            #MyList_sub[:] = []
            List_sub = ['Mode_of_operation_policy','Joint_holder_policy','Offered_scheme_policy',
                        'Occupation_of_account_holder_policy','Account_Status_Policy','Account_type_policy','Branch_change_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)
            
        elif MyList.curselection()[0]==3:
            #MyList_sub[:] = []
            List_sub = ['SAN_type_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)
            
        elif MyList.curselection()[0]==4:
            #MyList_sub[:] = []
            List_sub = ['Staffflag_policy','Mobile_banking_policy','AddressProof_Document_policy',
                        'AddressProof_flag_policy','Behaviour_risk_policy','Cstomer_Age_policy','Customer_income_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)
            
        elif MyList.curselection()[0]==5:
            List_sub = ['Modified_partPayment_policy','Loan_interestType_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)
            
        elif MyList.curselection()[0]==6:
            tkMessageBox.showinfo("Important Info", "Policies not yet implemented")
            #MyList_sub[:] = []
            List_sub = []
            for i in List_sub:
                MyList_sub.insert(END,i)
            
        elif MyList.curselection()[0]==7:
            #MyList_sub[:] = []
            List_sub = ['Available_balance_policy','Drawing_power_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)
            
        else:
            #MyList_sub = []
            List_sub = ['Transaction_days_policy','Transaction_remarks_policy','Transaction_type_policy']
            for i in List_sub:
                MyList_sub.insert(END,i)  
    else:
        'Please Select A Valid Policy'


#<----------for reseting purpose---->
def reset_everything():
    MyList_sub.delete(0,END)
    text0.delete('1.0',END)
    text1.delete('1.0',END)
    var.set("Enter query info")
    E1.delete(0,END)
#<----------Just to erase PNL info---->
def reset_info():
    text0.delete('1.0',END)
    text1.delete('1.0',END)

#<--------Sub dividing 2nd frame of top part-------------->
Sub_Top_part1 = LabelFrame(Top_part2, width= 300, height=50, text='Type of Customer Data')
Sub_Top_part1.pack(side = LEFT)
Sub_Top_part2 = Frame(Top_part2, width=50, height=100)
Sub_Top_part2.pack(side = LEFT)
Sub_Top_part3 = LabelFrame(Top_part2, width=300, height=50, text='Type of relevent KYC')
Sub_Top_part3.pack(side = LEFT)
Sub_Top_part4 = Frame(Top_part2, width=50, height=100)
Sub_Top_part4.pack(side = LEFT)
Sub_Top_part5 = LabelFrame(Top_part2, width=100, height=50, text='KYC for individual')
Sub_Top_part5.pack(side = RIGHT)

#<---------main policy scroll bar and lists------------------->
scrollbar1 = Scrollbar(Sub_Top_part1)
scrollbar1.pack( side = LEFT, fill = Y)
MyList = Listbox(Sub_Top_part1)
List_main = ['Biller_type','Branch_policies','Branch_Change','Cheque_books','Customer_data',
          'Loan_strategy','Locker_data','Offered_scheme','Transaction_data']
for i in List_main:
    MyList.insert(END,i)
MyList.pack(side=LEFT, fill=BOTH)
scrollbar1.config(command = MyList.yview)

#<----------sub policies scroll bar and list------------------->
scrollbar2 = Scrollbar(Sub_Top_part3)
scrollbar2.pack( side = LEFT, fill = Y)
MyList_sub = Listbox(Sub_Top_part3, yscrollcommand = scrollbar2.set, width=30)
List_sub = []
for i in List_sub:
    MyList_sub.insert(END,i)
MyList_sub.pack(side=LEFT, fill=BOTH)
scrollbar2.config(command = MyList_sub.yview)

#<------------------Bottom part of frame--------------------------->
Bottom_part = LabelFrame(root, width=800, height=450, text ='Policy informaion and PNL report')
Bottom_part.pack( side = BOTTOM )

#<------------------Dividing bottom part into 3 frame-------------->
Sub_Bottom_part1 = LabelFrame(Bottom_part, width=375, height=400, text ='Policy informaion goes here')
Sub_Bottom_part1.pack(side = LEFT)
Sub_Bottom_part2 = Frame(Bottom_part, width=50, height=450)
Sub_Bottom_part2.pack(side = LEFT)
Sub_Bottom_part3 = LabelFrame(Bottom_part, width=375, height=400, text ='PNL informaion goes here')
Sub_Bottom_part3.pack(side = RIGHT)

#<-----------------Entries and Check Buttons-------------------------->
CheckVar = IntVar()
C1 = Checkbutton(Sub_Top_part5, text = "Policy for individual", variable = CheckVar, onvalue = 1, offvalue = 0, height=5, width = 20, command=set_info)
C1.pack()
var = StringVar()
label = Message( Sub_Top_part5, textvariable=var, relief=RAISED, width=100)
var.set("Enter query info")
label.pack(anchor=CENTER, side=TOP)
E1 = Entry(Sub_Top_part5, bd =5)
E1.pack(anchor=CENTER)

#<------------------Buttons--------------->
B1 = Button(Top_part3, text ="Confirm", command = policy_caller, relief='groove', fg='white', bg = 'dark blue')
B1.pack(anchor=CENTER, side = LEFT)
B2 = Button(Top_part3, text ="Get PNL", command = get_pnl, relief='groove', fg='white', bg = 'dark blue')
B2.pack(anchor=CENTER, side=LEFT)
B3 = Button(Top_part3, text ="Reset", command = reset_everything, relief='groove', fg='white', bg = 'dark blue')
B3.pack(anchor=CENTER, side=LEFT)
B4 = Button(Top_part3, text ="Reset Info Only", command = reset_info, relief='groove', fg='white', bg = 'dark blue')
B4.pack(anchor=CENTER, side=LEFT)
B5 = Button(Sub_Top_part5, command = get_pnl, text ="Confirm", relief='groove', fg='white', bg = 'dark blue')
B5.pack(side = BOTTOM)

#<-------------------text boxes------------>
text0 = Text(Sub_Bottom_part1,fg = 'blue', bg = 'light yellow')
text0.pack()
text1 = Text(Sub_Bottom_part3,fg = 'red', bg = 'light yellow')
text1.pack()

root.mainloop()
